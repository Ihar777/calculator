<?php
// Подключение к базе данных MySQL
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "calculator";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных от клиента
$loanAmountInitial = $_POST['loanAmount'];
$loanAmount = $_POST['loanAmount'];
$interestRate = $_POST['interestRate'];
$loanTerm = $_POST['loanTerm'];

// Расчет платежей
$monthlyInterestRate = $interestRate / 12 / 100;
$monthlyPayment = ($loanAmount * $monthlyInterestRate) / (1 - pow(1 + $monthlyInterestRate, -$loanTerm));

// Создание таблицы платежей
$table = '<table>
            <tr>
                <th>Номер платежа</th>
                <th>Дата платежа</th>
                <th>Проценты</th>
                <th>Погашение основного долга</th>
                <th>Остаток основного долга</th>
            </tr>';

$totalPayment = 0;
for ($i = 1; $i <= $loanTerm; $i++) {
    $interest = $loanAmount * $monthlyInterestRate;
    $principal = $monthlyPayment - $interest;
    $loanAmount -= $principal;
    $totalPayment += $monthlyPayment;

    $table .= '<tr>
                    <td>' . $i . '</td>
                    <td>' . date("Y-m-d", strtotime("+{$i} months")) . '</td>
                    <td>' . number_format($interest, 2) . '</td>
                    <td>' . number_format($principal, 2) . '</td>
                    <td>' . number_format($loanAmount, 2) . '</td>
                </tr>';
}

$table .= '</table>';

// Сохранение истории калькуляций в базе данных
$sql = "INSERT INTO calculations (loan_amount, interest_rate, loan_term, monthly_payment, total_payment) 
        VALUES ('$loanAmountInitial', '$interestRate', '$loanTerm', '$monthlyPayment', '$totalPayment')";

$conn->query($sql);

$conn->close();

// Отправка данных обратно клиенту
$response = array(
    'table' => $table,
    'monthlyPayment' => $monthlyPayment,
    'totalPayment' => $totalPayment
);

echo json_encode($response);
?>
