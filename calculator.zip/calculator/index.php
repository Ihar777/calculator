<!DOCTYPE html>
<html>
<head>
    <title>Кредитный калькулятор</title>
    <script src="script.js"></script>
</head>
<body>
    <h1>Кредитный калькулятор</h1>
    
    <label for="loanAmount">Сумма кредита:</label>
    <input type="text" id="loanAmount"><br>
    
    <label for="interestRate">Процентная ставка:</label>
    <input type="text" id="interestRate"><br>
    
    <label for="loanTerm">Срок кредита (в месяцах):</label>
    <input type="text" id="loanTerm"><br>
    
    <button onclick="calculateLoan()">Рассчитать</button>
    
    <h2>Таблица платежей:</h2>
    <div id="paymentTable"></div>
    
    <h2>Ежемесячный платеж:</h2>
    <div id="monthlyPayment"></div>
    
    <h2>Общий платеж:</h2>
    <div id="totalPayment"></div>

<?php include 'backend.php'; ?>

</body>
</html>
