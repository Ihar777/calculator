-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:8889
-- Время создания: Июл 09 2023 г., 19:38
-- Версия сервера: 5.7.26
-- Версия PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- База данных: `calculator`
--

-- --------------------------------------------------------

--
-- Структура таблицы `calculations`
--

CREATE TABLE `calculations` (
  `id` int(11) NOT NULL,
  `loan_amount` decimal(10,2) NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL,
  `loan_term` int(11) NOT NULL,
  `monthly_payment` decimal(10,2) NOT NULL,
  `total_payment` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `calculations`
--

INSERT INTO `calculations` (`id`, `loan_amount`, `interest_rate`, `loan_term`, `monthly_payment`, `total_payment`) VALUES
(31, '1000.00', '9.00', 24, '45.68', '1096.43');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `calculations`
--
ALTER TABLE `calculations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `calculations`
--
ALTER TABLE `calculations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;