// Функция для отправки данных на сервер и обновления таблицы платежей
function calculateLoan() {
  const loanAmount = document.getElementById('loanAmount').value;
  const interestRate = document.getElementById('interestRate').value;
  const loanTerm = document.getElementById('loanTerm').value;

  // Создание объекта XMLHttpRequest для выполнения AJAX-запроса
  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'backend.php', true);

  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

  // Обработчик события получения ответа от сервера
  xhr.onload = function() {
      if (xhr.status === 200) {
          const response = JSON.parse(xhr.responseText);

          // Обновление таблицы платежей
          document.getElementById('paymentTable').innerHTML = response.table;

          // Отображение ежемесячного и общего платежей
          document.getElementById('monthlyPayment').innerHTML = response.monthlyPayment.toFixed(2);
          document.getElementById('totalPayment').innerHTML = response.totalPayment.toFixed(2);
      }
  };

  // Отправка данных на сервер
  xhr.send('loanAmount=' + loanAmount + '&interestRate=' + interestRate + '&loanTerm=' + loanTerm);
}
